/* eslint-disable prettier/prettier */
import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  Image,
  TouchableOpacity,
  SafeAreaView,
  Dimensions,
  Animated,
} from "react-native";
import AppHeader from "../widgets/AppHeader";
import tmh_styles from "../styles/tmh_styles";
import { HEADER_HEIGHT_THRESHOLD, BLOCK_HEIGHT_THRESHOLD } from "../resources/data/Constants";
import SearchBar from "./SearchBar";

const WhiskyBrands = ({ navigation }) => {
  const screenDimensions = Dimensions.get("screen");

  const [rightButtons] = useState([]);
  const [headerHeight] = useState(
    (HEADER_HEIGHT_THRESHOLD * screenDimensions.height) / 100
  );
  const [blockHeight] = useState(
    (BLOCK_HEIGHT_THRESHOLD * screenDimensions.height) / 100
  );

  const whiskyProducts = [
    { id: "1", name: "Johnnie Walker Black Label", size: "750ml", price: "R799.00", image: require("../resources/assets/arrival1.webp") },
    { id: "2", name: "Jameson Irish Whiskey", size: "750ml", price: "R599.00", image: require("../resources/assets/arrival1.webp") },
    { id: "3", name: "Chivas Regal 12", size: "750ml", price: "R699.00", image: require("../resources/assets/arrival1.webp") },
    { id: "4", name: "Glenfiddich 15", size: "750ml", price: "R1199.00", image: require("../resources/assets/arrival1.webp") },
    { id: "5", name: "Macallan 12", size: "750ml", price: "R1299.00", image: require("../resources/assets/arrival1.webp") },
    { id: "6", name: "Lagavulin 16", size: "750ml", price: "R1399.00", image: require("../resources/assets/arrival1.webp") },
    { id: "7", name: "Talisker 10", size: "750ml", price: "R1099.00", image: require("../resources/assets/arrival1.webp") },
  ];

  const renderWhiskyCard = ({ item }) => {
    const scale = new Animated.Value(1);

    const handlePressIn = () => {
      Animated.spring(scale, {
        toValue: 0.97,
        useNativeDriver: true,
      }).start();
    };

    const handlePressOut = () => {
      Animated.spring(scale, {
        toValue: 1,
        friction: 3,
        useNativeDriver: true,
      }).start();
    };

    return (
      <Animated.View style={{ transform: [{ scale }], marginBottom: 16, width: "48%" }}>
        <TouchableOpacity
          style={styles.card}
          activeOpacity={0.9}
          onPress={() => navigation.navigate("ProductDetails", { product: item })}
          onPressIn={handlePressIn}
          onPressOut={handlePressOut}
        >
          <Image
            source={item.image}
            style={styles.productImage}
            resizeMode="cover"
          />
          <View style={styles.cardContent}>
            <Text style={styles.name}>{item.name}</Text>
            <Text style={styles.size}>{item.size}</Text>
            <Text style={styles.price}>{item.price}</Text>
          </View>
        </TouchableOpacity>
      </Animated.View>
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <AppHeader
        title={"Whisky Brands"}
        isGradient={false}
        backgroundColor={"#c99742"}
        rightButtons={rightButtons}
        height={headerHeight}
        titleStyle={tmh_styles.header_title_tmb}
        isShowShadow={true}
        navigation={navigation}
        isBack={true}
        backButtonStyle={{ width: 35, height: 25, alignItems: "center" }}
        backIconColor={"black"}
        logoImage={null}
      />

      {/* Search Bar */}
      <SearchBar query={""} setQuery={() => {}} />

      {/* Whisky Grid using flexWrap */}
      <View style={styles.grid}>
        {whiskyProducts.map((item) => renderWhiskyCard({ item }))}
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#0d0d0d",
  },
  grid: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
    marginTop: 12,
  },
  card: {
    backgroundColor: "#1c1c1c",
    borderRadius: 16,
    overflow: "hidden",
    elevation: 10,
    shadowColor: "#000",
    shadowOpacity: 0.5,
    shadowOffset: { width: 0, height: 5 },
    shadowRadius: 10,
     borderColor: "#c99742",
    borderWidth: 1,
  },
  productImage: {
    width: "100%",
    height: 180,
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
  },
  cardContent: {
    padding: 12,
  },
  name: {
    fontSize: 16,
    fontWeight: "700",
    color: "#fff",
    marginBottom: 4,
  },
  size: {
    fontSize: 13,
    color: "#bbb",
    marginBottom: 6,
  },
  price: {
    fontSize: 15,
    fontWeight: "bold",
    color: "#c99742",
  },
});

export default WhiskyBrands;
