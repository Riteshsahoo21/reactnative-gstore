/* eslint-disable quotes */
/* eslint-disable prettier/prettier */
import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  FlatList,
  Image,
  StyleSheet,
  TouchableOpacity,
  Animated,
  Platform,
  ToastAndroid,
  Alert,
  Modal,
} from "react-native";
import tmh_styles from "../styles/tmh_styles";
import AppHeader from "../widgets/AppHeader";
import AsyncStorage from "@react-native-async-storage/async-storage";
import axios from "axios";

const IMAGE_BASE_URL = "https://ik.imagekit.io/thegrandstore/images/products/";
const API_WISHLIST_TOGGLE = "https://grandstore.co.za/api/customer/wishlist/add";
const API_GET_WISHLIST = "https://grandstore.co.za/api/customer/wishlist";

const ViewAll = ({ route, navigation }) => {
  const { category_title, products } = route.params;
  const [wishlistItemIds, setWishlistItemIds] = useState(new Set());
 const [selectedProduct, setSelectedProduct] = useState(null);
   const [isModalVisible, setIsModalVisible] = useState(false);
 
  useEffect(() => {
    fetchWishlist();
  }, []);

  const showMessage = (message) => {
    if (Platform.OS === "android") {
      ToastAndroid.show(message, ToastAndroid.SHORT);
    } else {
      Alert.alert(message);
    }
  };

  const getImageUrl = (imagePath) => {
  if (!imagePath || typeof imagePath !== "string") return ""; // Return empty string or fallback image
  return imagePath.startsWith("http") ? imagePath : `${IMAGE_BASE_URL}${imagePath}`;
};

  const fetchWishlist = async () => {
    try {
      const token = await AsyncStorage.getItem("userToken");
      if (!token) return;

      const res = await axios.get(API_GET_WISHLIST, {
        headers: {
          Authorization: `Bearer ${token}`,
          Accept: "application/json",
        },
      });

      const wishlistData = res.data.data || [];
      const ids = wishlistData.map((item) => item.id);
      setWishlistItemIds(new Set(ids));
    } catch (err) {
      console.error("Failed to fetch wishlist:", err);
    }
  };

  const toggleWishlist = async (product) => {
    try {
      const token = await AsyncStorage.getItem("userToken");
      if (!token) {
        showMessage("Please sign in to manage your wishlist.");
        return;
      }

      await axios.post(
        API_WISHLIST_TOGGLE,
        { productid: product.id },
        {
          headers: {
            Authorization: `Bearer ${token}`,
            Accept: "application/json",
          },
        }
      );

      const updatedSet = new Set(wishlistItemIds);
      if (updatedSet.has(product.id)) {
        updatedSet.delete(product.id);
        showMessage("Removed from Wishlist");
      } else {
        updatedSet.add(product.id);
        showMessage("Added to Wishlist");
      }
      setWishlistItemIds(updatedSet);
    } catch (error) {
      console.error("Toggle wishlist failed:", error);
      showMessage("Something went wrong. Please try again.");
    }
  };

  const renderProduct = ({ item }) => {
    const scale = new Animated.Value(1);
    const isInWishlist = wishlistItemIds.has(item.id);

    const handlePressIn = () => {
      Animated.spring(scale, { toValue: 0.97, useNativeDriver: true }).start();
    };

    const handlePressOut = () => {
      Animated.spring(scale, { toValue: 1, friction: 3, useNativeDriver: true }).start();
    };

    return (
      <Animated.View style={{ transform: [{ scale }], marginBottom: 16, width: "48%" }}>
        <TouchableOpacity
          style={styles.card}
          activeOpacity={0.9}
          onPress={() => navigation.navigate("ProductDetails", { product: item })}
          onPressIn={handlePressIn}
          onPressOut={handlePressOut}
        >
          <TouchableOpacity
            style={styles.wishlistIcon}
            onPress={() => toggleWishlist(item)}
          >
            <Image
              source={
                isInWishlist
                  ? require("../resources/assets/heart.png")
                  : require("../resources/assets/wishlist.png")
              }
              style={[styles.icon2, { tintColor: isInWishlist ? "red" : "white" }]}
            />
          </TouchableOpacity>

          <Image source={{ uri: getImageUrl(item.image) }} style={styles.productImage} />

          <View style={styles.cardContent}>
            <Text style={styles.productName}>
              {item.name.length > 20 ? item.name.slice(0, 20) + "..." : item.name}
            </Text>
            {item.size && <Text style={styles.size}>{item.size}</Text>}
            <View style={styles.priceRow}>
              <Text style={styles.productPrice}>
                R{item.price}
                <Text style={styles.superscript}>00</Text>
              </Text>
              <TouchableOpacity style={styles.cartBtn}
               onPress={() => {
              setSelectedProduct(item);
              setIsModalVisible(true);
            }}>
                <Image source={require("../resources/assets/bag.png")} style={styles.icon1} />
              </TouchableOpacity>
            </View>
          </View>
        </TouchableOpacity>
      </Animated.View>
    );
  };

  return (
    <View style={styles.container}>
      <AppHeader
        title={category_title || "Products"}
        isGradient={false}
        backgroundColor="#c99742"
        titleStyle={tmh_styles.header_title_tmb}
        isShowShadow={true}
        isBack={true}
        backButtonStyle={{ width: 35, height: 25, alignItems: "center" }}
        backIconColor="black"
        logoImage={null}
        navigation={navigation}
      />
      <FlatList
        data={products}
        renderItem={renderProduct}
        keyExtractor={(item) => item.id.toString()}
        numColumns={2}
        columnWrapperStyle={{ justifyContent: "space-between" }}
        contentContainerStyle={{ padding: 10 }}
      />
       {/* === Modal Overlay === */}
          <Modal
        transparent
        visible={isModalVisible}
        animationType="fade"
        onRequestClose={() => setIsModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContainer}>
            {/* Product Image */}
            <Image
              source={{ uri: getImageUrl(selectedProduct?.image) }}
              style={styles.modalImage}
            />
      
            {/* Product Info */}
            <Text style={styles.modalProductName}>{selectedProduct?.name}</Text>
      
            {selectedProduct?.size && (
              <Text style={styles.modalProductSize}>Size: {selectedProduct.size}</Text>
            )}
      
            <Text style={styles.modalProductPrice}>
              R{selectedProduct?.price}
            </Text>
      
            {/* Divider */}
            <View style={styles.modalDivider} />
      
            {/* Buttons */}
            <TouchableOpacity
              style={styles.confirmBtn}
              onPress={() => {
                // handle add to cart logic here
                setIsModalVisible(false);
              }}
            >
              <Text style={styles.confirmBtnText}>🛒 Add to Cart</Text>
            </TouchableOpacity>
      
            <TouchableOpacity
              style={styles.closeBtn}
              onPress={() => setIsModalVisible(false)}
            >
              <Text style={styles.closeBtnText}>✖ Close</Text>
            </TouchableOpacity>
          </View>
        </View>
          </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#0d0d0d" },
  card: {
    backgroundColor: "#1c1c1c",
    borderRadius: 16,
    overflow: "hidden",
    elevation: 10,
    shadowColor: "#000",
    shadowOpacity: 0.5,
    shadowOffset: { width: 0, height: 5 },
    shadowRadius: 10,
    borderColor: "#c99742",
    borderWidth: 1,
  },
  productImage: {
    width: "100%",
    height: 180,
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
  },
  cardContent: { padding: 12 },
  productName: { fontSize: 14, fontWeight: "700", color: "#fff", marginBottom: 4 },
  size: { fontSize: 12, color: "#bbb", marginBottom: 6 },
  productPrice: { color: "#9a7823ff", fontSize: 16, fontWeight: "700", marginVertical: 5 },
  priceRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginTop: 6,
  },
  wishlistIcon: {
    position: "absolute",
    top: 10,
    right: 10,
    zIndex: 10,
    backgroundColor: "#1c1c1c",
    padding: 6,
    borderRadius: 20,
  },
  superscript: {
    fontSize: 10,
    lineHeight: 16,
    textAlignVertical: "top",
  },
  cartBtn: { marginLeft: 8, backgroundColor: "#c99742", padding: 6, borderRadius: 8 },
  icon1: { width: 20, height: 20 },
  icon2: { width: 22, height: 22 },
   // Modal Styles
 modalOverlay: {
  position: "absolute",
  top: 0,
  left: 0,
  right: 0,
  bottom: 0,
  backgroundColor: "rgba(0,0,0,0.75)",
  justifyContent: "center",
  alignItems: "center",
},

modalContainer: {
  backgroundColor: "#1c1c1c",
  borderRadius: 20,
  paddingVertical: 25,
  paddingHorizontal: 20,
  width: "85%",
  alignItems: "center",
  borderWidth: 1,
  borderColor: "#c99742",
  elevation: 5,
  shadowColor: "#000",
  shadowOffset: { width: 0, height: 2 },
  shadowOpacity: 0.5,
  shadowRadius: 8,
},

modalImage: {
  width: 140,
  height: 140,
  borderRadius: 14,
  marginBottom: 15,
  resizeMode: "contain",
},

modalProductName: {
  color: "#fff",
  fontSize: 18,
  fontWeight: "600",
  textAlign: "center",
  marginBottom: 5,
},

modalProductSize: {
  color: "#bbb",
  fontSize: 14,
  marginBottom: 8,
},

modalProductPrice: {
  color: "#f5c242",
  fontSize: 22,
  fontWeight: "bold",
  marginBottom: 10,
},

modalDivider: {
  height: 1,
  width: "100%",
  backgroundColor: "#333",
  marginVertical: 15,
},

confirmBtn: {
  backgroundColor: "#f5c242",
  paddingVertical: 12,
  paddingHorizontal: 30,
  borderRadius: 10,
  width: "100%",
  alignItems: "center",
  marginBottom: 12,
},

confirmBtnText: {
  color: "#000",
  fontSize: 16,
  fontWeight: "700",
},

closeBtn: {
  paddingVertical: 10,
  width: "100%",
  alignItems: "center",
},

closeBtnText: {
  color: "#bbb",
  fontSize: 14,
  fontWeight: "500",
},

});

export default ViewAll;
