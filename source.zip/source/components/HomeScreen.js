/* eslint-disable prettier/prettier */
/* eslint-disable quotes */
import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Image,
  TouchableOpacity,
  FlatList,
  ActivityIndicator,
  ToastAndroid,
  Platform,
  Alert,
  Modal,
  Animated,
  Easing,
} from "react-native";
import axios from "axios";
import AsyncStorage from "@react-native-async-storage/async-storage";
import VideoSlider from "./VideoSlider";
import { APP_FONT } from "../resources/data/Fonts";

// === Constants ===
const IMAGE_BASE_URL = "https://ik.imagekit.io/thegrandstore/images/products/";
const API_BASE = "http://grandstore.co.za/api";
const API_WISHLIST_TOGGLE = "https://grandstore.co.za/api/customer/wishlist/add";
const API_GET_WISHLIST = "https://grandstore.co.za/api/customer/wishlist";
const API_CART_ADD = "https://grandstore.co.za/api/cart/add";
const API_CART_SHOW = "https://grandstore.co.za/api/cart/show";

// === Toast Helper ===
const showMessage = (message) => {
  if (Platform.OS === "android") {
    ToastAndroid.show(message, ToastAndroid.SHORT);
  } else {
    Alert.alert("", message);
  }
};

const HomeScreen = ({ navigation }) => {
  const [wishlistItemIds, setWishlistItemIds] = useState(new Set());
  const [cartItems, setCartItems] = useState(new Set());
  const [categories, setCategories] = useState([]);
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [quantity, setQuantity] = useState(1);
  const [sections, setSections] = useState({
    newArrivals: [],
    trending: [],
    specialOffers: [],
    featured: [],
    bestSeller: [],
    wineBrands: [],
    whiskyBrands: [],
    vodkaBrands: [],
  });
  const [loading, setLoading] = useState(true);
  const [userName, setUserName] = useState(null);
  const [selectedProduct, setSelectedProduct] = useState(null);

  // === Add-to-Cart Animation ===
  const scaleAnim = useState(new Animated.Value(1))[0];
  const opacityAnim = useState(new Animated.Value(1))[0];

  const animateButton = () => {
    Animated.parallel([
      Animated.sequence([
        Animated.timing(scaleAnim, {
          toValue: 1.2,
          duration: 150,
          easing: Easing.out(Easing.ease),
          useNativeDriver: true,
        }),
        Animated.timing(scaleAnim, {
          toValue: 1,
          duration: 150,
          easing: Easing.in(Easing.ease),
          useNativeDriver: true,
        }),
      ]),
      Animated.sequence([
        Animated.timing(opacityAnim, {
          toValue: 0,
          duration: 100,
          useNativeDriver: true,
        }),
        Animated.timing(opacityAnim, {
          toValue: 1,
          duration: 150,
          useNativeDriver: true,
        }),
      ]),
    ]).start();
  };

  // === API Calls ===
  const fetchUserName = async () => {
    try {
      const name = await AsyncStorage.getItem("userName");
      if (name) setUserName(name);
    } catch (err) {
      console.error("Error fetching user name:", err);
    }
  };

  const fetchWishlist = async () => {
    try {
      const token = await AsyncStorage.getItem("userToken");
      if (!token) return;
      const res = await axios.get(API_GET_WISHLIST, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const wishlist = res.data.data || [];
      setWishlistItemIds(new Set(wishlist.map((item) => item.id)));
    } catch (err) {
      console.error("Error fetching wishlist:", err);
    }
  };

  const fetchCartItems = async () => {
    try {
      const token = await AsyncStorage.getItem("userToken");
      if (!token) return;

      const res = await axios.get(API_CART_SHOW, {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (res.data.status === 1 && res.data.cart) {
        const ids = new Set(res.data.cart.map((item) => item.productid));
        setCartItems(ids);
      }
    } catch (err) {
      console.error("Error fetching cart items:", err);
    }
  };

  const toggleWishlist = async (item) => {
    try {
      const token = await AsyncStorage.getItem("userToken");
      if (!token) {
        showMessage("You must be logged in to use wishlist.");
        return;
      }

      await axios.post(
        API_WISHLIST_TOGGLE,
        { productid: item.id },
        {
          headers: {
            Authorization: `Bearer ${token}`,
            Accept: "application/json",
          },
        }
      );

      const updatedIds = new Set(wishlistItemIds);
      if (updatedIds.has(item.id)) {
        updatedIds.delete(item.id);
        showMessage("Removed from Wishlist");
      } else {
        updatedIds.add(item.id);
        showMessage("Added to Wishlist");
      }

      setWishlistItemIds(updatedIds);
    } catch (error) {
      console.error("Wishlist toggle failed:", error);
      showMessage("Failed to update wishlist");
    }
  };

  const fetchAllData = async () => {
    try {
      const endpoints = {
        newArrivals: "/new-arrivals",
        trending: "/trending",
        specialOffers: "/special-offers",
        featured: "/featured",
        bestSeller: "/best-seller",
        wineBrands: "/getBrandSlider/14",
        whiskyBrands: "/getBrandSlider/5",
        vodkaBrands: "/getBrandSlider/13",
        categories: "/categories",
      };

      const responses = await Promise.all(
        Object.values(endpoints).map((url) => axios.get(`${API_BASE}${url}`))
      );

      setSections({
        newArrivals: responses[0].data.data || [],
        trending: responses[1].data.data || [],
        specialOffers: responses[2].data.data || [],
        featured: responses[3].data.data || [],
        bestSeller: responses[4].data.data || [],
        wineBrands: responses[5].data.data || [],
        whiskyBrands: responses[6].data.data || [],
        vodkaBrands: responses[7].data.data || [],
      });

      setCategories(responses[8].data.data || []);
    } catch (err) {
      console.error("Error fetching data:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleAddToCart = async () => {
    if (!selectedProduct) return;

    try {
      const token = await AsyncStorage.getItem("userToken");
      if (!token) {
        showMessage("You must be logged in to add to cart.");
        return;
      }

      const payload = {
        productid: selectedProduct.productid,
        variantid: selectedProduct.id || null,
        vendorid: selectedProduct.vendorid || 1,
        quantity,
      };

      const res = await axios.post(API_CART_ADD, payload, {
        headers: {
          Authorization: `Bearer ${token}`,
          Accept: "application/json",
        },
      });

      if (res.data.status === 1) {
        showMessage("✅ Added to cart");
        setCartItems(new Set([...cartItems, selectedProduct.id]));
        animateButton();
        setTimeout(() => setIsModalVisible(false), 1000);
      } else {
        showMessage(res.data.message || "Failed to add to cart");
      }
    } catch (err) {
      console.error("Add to cart failed:", err?.response?.data || err.message);
      showMessage("❌ Could not add to cart");
    }
  };

  useEffect(() => {
    fetchUserName();
    fetchAllData();
    fetchWishlist();
    fetchCartItems();
  }, []);

  const getImageUrl = (imagePath) =>
    imagePath?.startsWith("http") ? imagePath : `${IMAGE_BASE_URL}${imagePath}`;

  const renderProduct = ({ item }) => {
    const isInWishlist = wishlistItemIds.has(item.id);
    const imageUrl = getImageUrl(item.image);

    return (
      <View style={styles.card}>
        <TouchableOpacity style={styles.wishlistIcon} onPress={() => toggleWishlist(item)}>
          <Image
            source={
              isInWishlist
                ? require("../resources/assets/heart.png")
                : require("../resources/assets/wishlist.png")
            }
            style={[styles.icon2, { tintColor: isInWishlist ? "red" : "white" }]}
          />
        </TouchableOpacity>

<TouchableOpacity
  onPress={() =>
    navigation.push("ProductDetails", {
      product: item,
      category: categories.find(cat => cat.id === item.category_id) || null, // pass category if exists
      related_products: sections.newArrivals
        .concat(sections.featured, sections.specialOffers) // combine relevant sections
        .filter(p => p.id !== item.id), // remove current product
    })
  }
>

          {imageUrl ? (
            <Image source={{ uri: imageUrl }} style={styles.productImage} />
          ) : (
            <View style={[styles.productImage, { backgroundColor: "#333" }]} />
          )}
        </TouchableOpacity>

        <Text style={styles.productName}>
          {item.name.length > 20 ? item.name.slice(0, 20) + "..." : item.name}
        </Text>

        {item.size && <Text style={styles.productSize}>{item.size}</Text>}

        <View style={styles.priceRow}>
          <Text style={styles.productPrice}>
            R{item.price}
            <Text style={styles.superscript}>00</Text>
          </Text>

          <TouchableOpacity
            style={styles.cartBtn}
            onPress={() => {
              setSelectedProduct(item);
              setIsModalVisible(true);
            }}
          >
            <Image source={require("../resources/assets/bag.png")} style={styles.icon1} />
          </TouchableOpacity>
        </View>
      </View>
    );
  };

  const renderVSectionTitle = (title, data) => (
    <View style={styles.sectionHeader}>
      <Text style={styles.sectionTitle}>{title}</Text>
      <TouchableOpacity
        onPress={() => navigation.navigate("ViewAll", { category_title: title, products: data })}
      >
        <Text style={styles.viewAll}>View All</Text>
      </TouchableOpacity>
    </View>
  );

  const renderBrandSlider = (brands) => (
    <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.brandContainer}>
      {brands.map((item) =>
        item.brandlogo ? (
          <Image
            key={item.brandslug}
            source={{ uri: item.brandlogo }}
            style={styles.brandImage}
            resizeMode="contain"
          />
        ) : null
      )}
    </ScrollView>
  );

  if (loading) {
    return (
      <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
        <ActivityIndicator size="large" color="#c99742" />
      </View>
    );
  }

  return (
    <View style={{ flex: 1 }}>
      <ScrollView style={styles.container}>
        <Text style={{ color: "#f5c242", fontSize: 20, fontWeight: "600", marginTop: 20 }}>
          {userName ? `Welcome, ${userName}` : "Please sign in"}
        </Text>

        <VideoSlider />

        {/* Categories */}
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginVertical: 15 }}>
          {categories.map((cat, index) => (
            <TouchableOpacity
              key={cat.id}
              onPress={() => navigation.navigate("ViewAll", { category_title: cat.name })}
              style={{ marginRight: 20 }}
            >
              <Text style={[styles.categoryText, index === 0 && styles.activeCategory]}>
                {cat.name}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        {/* Product Sections */}
        {renderVSectionTitle("Special Offers", sections.specialOffers)}
        <FlatList
          horizontal
          data={sections.specialOffers}
          renderItem={renderProduct}
          keyExtractor={(item) => item.id.toString()}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ paddingVertical: 10 }}
        />

        <Text style={styles.brandheading}>Top Wine Brands</Text>
        <View style={styles.verticleline} />
        {renderBrandSlider(sections.wineBrands)}

        {renderVSectionTitle("New Arrivals", sections.newArrivals)}
        <FlatList
          horizontal
          data={sections.newArrivals}
          renderItem={renderProduct}
          keyExtractor={(item) => item.id.toString()}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ paddingVertical: 10 }}
        />

        {renderVSectionTitle("Featured Collection", sections.featured)}
        <FlatList
          horizontal
          data={sections.featured}
          renderItem={renderProduct}
          keyExtractor={(item) => item.id.toString()}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ paddingVertical: 10 }}
        />

        <Text style={styles.brandheading}>Top Whisky Brands</Text>
        <View style={styles.verticleline} />
        {renderBrandSlider(sections.whiskyBrands)}

        {renderVSectionTitle("Best Seller", sections.bestSeller)}
        <FlatList
          horizontal
          data={sections.bestSeller}
          renderItem={renderProduct}
          keyExtractor={(item) => item.id.toString()}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ paddingVertical: 10 }}
        />

        <Text style={styles.brandheading}>Top Vodka Brands</Text>
        <View style={styles.verticleline} />
        {renderBrandSlider(sections.vodkaBrands)}

        {renderVSectionTitle("Trending Now", sections.trending)}
        <FlatList
          horizontal
          data={sections.trending}
          renderItem={renderProduct}
          keyExtractor={(item) => item.id.toString()}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ paddingVertical: 10 }}
        />
      </ScrollView>

      {/* Modal */}
      <Modal
        transparent
        visible={isModalVisible}
        animationType="fade"
        onRequestClose={() => setIsModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContainer}>
            <Image
              source={{ uri: getImageUrl(selectedProduct?.image) }}
              style={styles.modalImage}
            />
            <Text style={styles.modalProductName}>{selectedProduct?.name}</Text>
            {selectedProduct?.size && (
              <Text style={styles.modalProductSize}>Size: {selectedProduct.size}</Text>
            )}
            <Text style={styles.modalProductPrice}>R{selectedProduct?.price}</Text>
            <View style={styles.modalDivider} />

            {/* Animated Add-to-Cart Button */}
            <Animated.View
              style={{
                transform: [{ scale: scaleAnim }],
                opacity: opacityAnim,
                width: "100%",
              }}
            >
              <TouchableOpacity
                style={[
                  styles.confirmBtn,
                  { backgroundColor: cartItems.has(selectedProduct?.id) ? "#4CAF50" : "#f5c242" },
                ]}
                onPress={!cartItems.has(selectedProduct?.id) ? handleAddToCart : null}
                activeOpacity={0.8}
              >
                <Text style={styles.confirmBtnText}>
                  {cartItems.has(selectedProduct?.id) ? "✅ Added to Cart" : "🛒 Add to Cart"}
                </Text>
              </TouchableOpacity>
            </Animated.View>

            <TouchableOpacity
              style={styles.closeBtn}
              onPress={() => setIsModalVisible(false)}
            >
              <Text style={styles.closeBtnText}>✖ Close</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
};

// === Styles ===
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#0d0d0d", paddingHorizontal: 15 },
  card: {
    backgroundColor: "#1C1C1C",
    borderRadius: 25,
    padding: 15,
    marginHorizontal: 10,
    width: 160,
    borderWidth: 1,
    borderColor: "#c99742",
  },
  wishlistIcon: {
    position: "absolute",
    top: 10,
    right: 10,
    zIndex: 1,
    backgroundColor: "#3B3E40",
    padding: 6,
    borderRadius: 20,
    elevation: 3,
  },
  superscript: { fontSize: 10, lineHeight: 16 },
  icon1: { width: 20, height: 20 },
  icon2: { width: 16, height: 16 },
  productImage: { width: "100%", height: 150, resizeMode: "cover", borderRadius: 24 },
  productName: { color: "#fff", fontWeight: "400", fontSize: 14 },
  productSize: { color: "#aaa", fontSize: 12 },
  priceRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  productPrice: { color: "#9a7823ff", fontSize: 16, fontWeight: "700", marginVertical: 5 },
  cartBtn: { backgroundColor: "#d19f42ff", padding: 8, borderRadius: 11 },
  sectionHeader: { flexDirection: "row", justifyContent: "space-between", marginVertical: 15 },
  sectionTitle: { fontWeight: "500", color: "#CCC", fontSize: 20, fontFamily: APP_FONT },
  viewAll: { color: "#f5c242", fontSize: 14 },
  categoryText: { color: "#ccc", fontSize: 18, fontWeight: "500" },
  activeCategory: { color: "#936e2bff", borderBottomWidth: 2, borderBottomColor: "#f5c242" },
  brandheading: { color: "#fff", fontSize: 24, textAlign: "center", marginVertical: 15 },
  verticleline: { height: 2, width: "65%", backgroundColor: "#c39f5f", alignSelf: "center" },
  brandContainer: { marginLeft: 10 },
  brandImage: { width: 100, height: 100, marginRight: 5, borderRadius: 8 },
  modalOverlay: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: "rgba(0,0,0,0.75)",
    justifyContent: "center",
    alignItems: "center",
  },
  modalContainer: {
    backgroundColor: "#1C1C1C",
    borderRadius: 20,
    padding: 20,
    alignItems: "center",
    width: "85%",
  },
  modalImage: { width: 150, height: 150, borderRadius: 15, marginBottom: 10 },
  modalProductName: { color: "#fff", fontSize: 18, fontWeight: "600" },
  modalProductSize: { color: "#aaa", fontSize: 14 },
  modalProductPrice: { color: "#f5c242", fontSize: 20, fontWeight: "bold", marginVertical: 5 },
  modalDivider: { width: "100%", height: 1, backgroundColor: "#333", marginVertical: 10 },
  confirmBtn: { paddingVertical: 12, borderRadius: 12, alignItems: "center" },
  confirmBtnText: { color: "#000", fontSize: 16, fontWeight: "600" },
  closeBtn: { marginTop: 10 },
  closeBtnText: { color: "#ccc", fontSize: 14 },
});

export default HomeScreen;
