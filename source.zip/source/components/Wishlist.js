/* eslint-disable prettier/prettier */
import React, { useState, useCallback } from "react";
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Image,
  Dimensions,
  ActivityIndicator,
} from "react-native";
import axios from "axios";
import { useFocusEffect } from "@react-navigation/native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import AppHeader from "../widgets/AppHeader";
import tmh_styles from "../styles/tmh_styles";

const API_GET_WISHLIST = "https://grandstore.co.za/api/customer/wishlist";
const API_TOGGLE_WISHLIST = "https://grandstore.co.za/api/customer/wishlist/add";

const Wishlist = ({ navigation }) => {
  const screenWidth = Dimensions.get("window").width;
  const numColumns = 2;
  const cardWidth = (screenWidth - 40) / numColumns;

  const [wishlist, setWishlist] = useState([]);
  const [loading, setLoading] = useState(true);

  const getImageUrl = (imagePath) => {
    if (!imagePath) return "";
    return imagePath.startsWith("http")
      ? imagePath
      : `https://ik.imagekit.io/thegrandstore/images/products/${imagePath}`;
  };

  const fetchWishlist = async () => {
    setLoading(true);
    try {
      const token = await AsyncStorage.getItem("userToken");
      if (!token) {
        console.warn("User not logged in");
        setWishlist([]);
        return;
      }

      const res = await axios.get(API_GET_WISHLIST, {
        headers: {
          Authorization: `Bearer ${token}`,
          Accept: "application/json",
        },
      });

      setWishlist(res.data.wishlist || []);
    } catch (error) {
      console.error("Failed to fetch wishlist:", error?.response?.data || error.message);
    } finally {
      setLoading(false);
    }
  };

  useFocusEffect(
    useCallback(() => {
      fetchWishlist();
    }, [])
  );

  const toggleWishlist = async (id) => {
    try {
      const token = await AsyncStorage.getItem("userToken");
      if (!token) return;

      const res = await axios.post(
        API_TOGGLE_WISHLIST,
        { productid: id },
        {
          headers: {
            Authorization: `Bearer ${token}`,
            Accept: "application/json",
          },
        }
      );

      if (res.data.status === 1) {
        // Refresh wishlist after toggle
        fetchWishlist();
      }
    } catch (error) {
      console.error("Failed to toggle wishlist:", error?.response?.data || error.message);
    }
  };

  const renderItem = ({ item }) => (
    <View style={[styles.card, { width: cardWidth }]}>
      <Image source={{ uri: getImageUrl(item.image) }} style={styles.productImage} />
      <View style={styles.details}>
        <Text style={styles.productName} numberOfLines={2}>
          {item.name}
        </Text>

        {item.price ? (
          <Text style={styles.productPrice}>R{item.price}</Text>
        ) : null}

        <TouchableOpacity
          style={styles.removeBtn}
          onPress={() => toggleWishlist(item.id)}
        >
          <Text style={styles.removeText}>Remove</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <AppHeader
        title={`My Wishlist (${wishlist.length})`}
        isGradient={false}
        backgroundColor={"#c99742"}
        rightButtons={[]}
        height={65}
        titleStyle={tmh_styles.header_title_tmb}
        isShowShadow={false}
        navigation={navigation}
        isBack={true}
        backButtonStyle={{ width: 35, height: 25, alignItems: "center" }}
        backIconColor={"black"}
        logoImage={null}
      />

      {loading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#c99742" />
        </View>
      ) : wishlist.length === 0 ? (
        <View style={styles.emptyContainer}>
          <View style={styles.Con}>
            <Image
              source={require("../resources/assets/data.png")}
              style={styles.emptyImage}
            />
            <Text style={styles.emptyText}>Your wishlist is empty</Text>
          </View>
        </View>
      ) : (
        <FlatList
          data={wishlist}
          key={numColumns}
          keyExtractor={(item) => item.id.toString()}
          renderItem={renderItem}
          numColumns={numColumns}
          columnWrapperStyle={styles.row}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#0d0d0d",
  },
  listContent: {
    paddingHorizontal: 12,
    paddingTop: 12,
    paddingBottom: 20,
  },
  row: {
    justifyContent: "space-between",
    marginBottom: 14,
  },
  Con: {
    backgroundColor: "#c99742",
    borderRadius: 25,
    padding: 20,
    margin: 40,
    alignItems: "center",
  },
  card: {
    backgroundColor: "#1c1c1c",
    borderRadius: 14,
    padding: 12,
    alignItems: "center",
    borderColor: "#c99742",
    borderWidth: 1,
    shadowColor: "#000",
    shadowOpacity: 0.2,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 2 },
    elevation: 5,
  },
  productImage: {
    width: "100%",
    height: 130,
    borderRadius: 10,
    resizeMode: "contain",
    marginBottom: 12,
  },
  details: {
    alignItems: "center",
  },
  productName: {
    fontSize: 15,
    color: "#fff",
    fontWeight: "600",
    marginBottom: 6,
    textAlign: "center",
  },
  productPrice: {
    fontSize: 15,
    color: "#c99742",
    marginBottom: 10,
  },
  removeBtn: {
    backgroundColor: "#c99742",
    paddingVertical: 6,
    paddingHorizontal: 18,
    borderRadius: 20,
  },
  removeText: {
    color: "#000",
    fontSize: 14,
    fontWeight: "bold",
  },
  emptyContainer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 20,
  },
  emptyText: {
    fontSize: 18,
    color: "#000",
    marginTop: 15,
  },
  emptyImage: {
    width: 80,
    height: 80,
    resizeMode: "contain",
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
});

export default Wishlist;
