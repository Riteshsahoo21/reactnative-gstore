/* eslint-disable quotes */
/* eslint-disable prettier/prettier */
/* eslint-disable react-native/no-inline-styles */
import React, { useRef, useState, useEffect } from "react";
import {
  View,
  Dimensions,
  FlatList,
  StyleSheet,
  ActivityIndicator,
} from "react-native";
import Video from "react-native-video";
import axios from "axios";

const { width } = Dimensions.get("screen");
const VIDEO_HEIGHT = 200;
const API_URL = "http://grandstore.co.za/api/banners";

const VideoSlider = () => {
  const [videos, setVideos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [currentIndex, setCurrentIndex] = useState(0);
  const flatListRef = useRef();

  const onViewRef = useRef(({ viewableItems }) => {
    if (viewableItems.length > 0) {
      setCurrentIndex(viewableItems[0].index);
    }
  });

  const viewConfigRef = useRef({ viewAreaCoveragePercentThreshold: 50 });

  // Fetch banners from API
  const fetchBanners = async () => {
    try {
      const response = await axios.get(API_URL);
      const bannerData = response.data.data.map((item) => ({
        id: item.id,
        url: item.image,
      }));
      setVideos(bannerData);
     // console.log(bannerData)
    } catch (err) {
      console.error("Failed to fetch banners:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBanners();
  }, []);

  if (loading) {
    return (
      <View style={[styles.container, { justifyContent: "center", alignItems: "center" }]}>
        <ActivityIndicator size="large" color="#c99742" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <FlatList
        ref={flatListRef}
        data={videos}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item, index }) => (
          <Video
            source={{ uri: item.url }}
            style={styles.video}
            resizeMode="cover"
            paused={currentIndex !== index} // Play only current video
            repeat
          />
        )}
        onViewableItemsChanged={onViewRef.current}
        viewabilityConfig={viewConfigRef.current}
      />

      {/* Pagination dots */}
      <View style={styles.pagination}>
        {videos.map((_, i) => (
          <View
            key={i}
            style={[styles.dot, { opacity: i === currentIndex ? 1 : 0.3 }]}
          />
        ))}
      </View>
    </View>
  );
};

export default VideoSlider;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#000",
    marginTop:25,
  },
  video: {
    width: width-10,
    height: VIDEO_HEIGHT+20,
  },
  pagination: {
    flexDirection: "row",
    justifyContent: "center",
    marginVertical: 10,
  },
  dot: {
    height: 8,
    width: 8,
    borderRadius: 4,
    backgroundColor: "#c99742",
    margin: 5,
  },
});
